"""python run.py  -> обучает двухстадийную систему и печатает/сохраняет метрики."""
import json, time, argparse
import numpy as np
import pandas as pd
from recsys.data import load, DAY
from recsys.snapshot import Snapshot
from recsys.retrieval import Retriever
from recsys.features import build_features, add_labels, FEATURES
from recsys.ranking import Ranker
from recsys.metrics import rank_metrics

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/retailrocket")
ap.add_argument("--window_days", type=int, default=14)
ap.add_argument("--n_cand", type=int, default=50)
ap.add_argument("--seed", type=int, default=0)
args = ap.parse_args()
t0 = time.time()
log = lambda m: print(f"[{time.time() - t0:5.0f}s] {m}", flush=True)

ds = load(args.data)
e = ds.events
log(f"data: {ds.source}; events={len(e):,} users={e.user.nunique():,} items={e.item.nunique():,}; "
    f"view/cart/buy={e.etype.value_counts().sort_index().tolist()}")
W = args.window_days * DAY
t_end = int(e["ts"].max()) + 1
T_test = t_end - W                       # тест: [T_test, t_end)
cutoffs = [(T_test - 2 * W, T_test - W), (T_test - W, T_test)]   # обучение ранкера: 2 окна подряд


def make_set(T0, T1):
    """Snapshot на T0 -> retrieval -> фичи -> метки из окна [T0,T1)."""
    snap = Snapshot(ds, T0)
    ret = Retriever(snap, n_total=args.n_cand, seed=args.seed)
    w = e[(e["ts"] >= T0) & (e["ts"] < T1)]
    users = np.sort(w["user"].unique())          # кто «пришёл» в окне (включая холодных)
    cands = ret.candidates(users)
    d = build_features(cands, snap, ret)
    d, pos = add_labels(d, ds, T0, T1, snap)
    pos = pos.reindex(users).dropna().astype(int)    # пользователи, у которых есть что угадывать
    d = d[d["user"].isin(pos.index)]
    d["pos_in_list"] = d.groupby("user").cumcount()  # порядок, в котором отдал retrieval
    return d, pos, snap, ret


train_parts = []
for T0, T1 in cutoffs:
    d, pos, _, ret = make_set(T0, T1)
    log(f"train window: users={d.user.nunique():,} rows={len(d):,} pos_rate={d.label.mean():.3%} "
        f"als_backend={ret.backend}")
    train_parts.append(d)
train = pd.concat(train_parts, ignore_index=True)
ranker = Ranker(FEATURES, seed=args.seed).fit(train)
log(f"ranker trained ({ranker.backend}) on {len(train):,} rows")

test, pos, snap, ret = make_set(T_test, t_end)
test["score_rank"] = ranker.predict(test)
test["score_retr"] = -test["pos_in_list"].astype(float)       # ALS/fresh/trend в порядке retrieval
log(f"test: users={len(pos):,} (cold users: {(snap.u_items[pos.index] == 0).sum():,})")

# Бейзлайн: глобальный «тренд за 7 дней» (без персонализации)
pop_rows = []
for u in pos.index:
    seen = set(snap.R.indices[snap.R.indptr[u]:snap.R.indptr[u + 1]])
    top = [it for it in ret.trend if it not in seen][:10]
    pop_rows += [(u, it, -r) for r, it in enumerate(top)]
pop = pd.DataFrame(pop_rows, columns=["user", "item", "score"])
pop, _ = add_labels(pop, ds, T_test, t_end, snap)

cold_mask = snap.u_items[pos.index] == 0
segments = {"all": pos.index, "warm": pos.index[~cold_mask], "cold": pos.index[cold_mask]}
res = {}
for seg, uidx in segments.items():
    if len(uidx) == 0:
        continue
    pc = pos.loc[uidx]
    sub = lambda df: df[df["user"].isin(uidx)]
    r = {}
    r["Popularity (trend 7d)"] = rank_metrics(sub(pop), "score", pc, ks=(10,))
    r["Retrieval order (ALS+fresh+trend)"] = rank_metrics(sub(test), "score_retr", pc, ks=(10, 50))
    r["Two-stage (retrieval + ranker)"] = rank_metrics(sub(test), "score_rank", pc, ks=(10, 50))
    res[seg] = r

n_known = int(snap.known.sum())
for seg, r in res.items():
    print(f"\n=== segment: {seg} (users={r['Popularity (trend 7d)']['n_users']:,}) ===")
    tab = pd.DataFrame({k: {m: v for m, v in x.items() if not m.startswith("_") and m != "n_users"}
                        for k, x in r.items()}).T
    tab["Coverage@10"] = [len(np.unique(x["_top_items"])) / n_known for x in r.values()]
    print(tab.round(4).to_string())
    res[seg] = {k: {m: v for m, v in x.items() if not m.startswith("_")} for k, x in r.items()}
    res[seg]["_coverage@10"] = tab["Coverage@10"].round(4).to_dict()

# Вклад источников и фичей: что делает ранкер для холодных товаров?
fresh_share = test.sort_values(["user", "score_rank"], ascending=[True, False]).groupby("user").head(10)["src_fresh"].mean()
print(f"\nдоля 'fresh' товаров в top-10 после ранкера: {fresh_share:.1%} (в 50 кандидатах: {test.src_fresh.mean():.1%})")
print(f"hit-rate fresh-кандидатов: {test[test.src_fresh == 1].label.mean():.3%}  vs ALS: {test[test.src_als == 1].label.mean():.3%}")
# Permutation importance по NDCG@10 (на подвыборке пользователей теста)
rng = np.random.default_rng(0)
sample_u = rng.choice(pos.index.values, size=min(1500, len(pos)), replace=False)
ts_ = test[test["user"].isin(sample_u)].copy(); pcs = pos.loc[sample_u]
base = rank_metrics(ts_.assign(s=ranker.predict(ts_)), "s", pcs)["NDCG@10"]
imp = {}
for f in FEATURES:
    x = ts_.copy(); x[f] = rng.permutation(x[f].values)
    imp[f] = base - rank_metrics(x.assign(s=ranker.predict(x)), "s", pcs)["NDCG@10"]
imp = dict(sorted(imp.items(), key=lambda kv: -kv[1]))
print("\nPermutation importance (падение NDCG@10 при перемешивании фичи):")
for k, v in list(imp.items())[:10]: print(f"  {k:18s} {v:+.4f}")
res["_importance"] = {k: round(v, 5) for k, v in imp.items()}

# График
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
for a, met in zip(ax, ["NDCG@10", "Recall@10"]):
    names = ["Popularity (trend 7d)", "Retrieval order (ALS+fresh+trend)", "Two-stage (retrieval + ranker)"]
    x = np.arange(3); wd = 0.26
    for j, seg in enumerate(["all", "warm", "cold"]):
        a.bar(x + (j - 1) * wd, [res[seg][n][met] for n in names], wd, label=seg)
    a.set_xticks(x); a.set_xticklabels(["Popularity", "Retrieval\n(ALS)", "Two-stage"]); a.set_title(met); a.legend()
plt.tight_layout(); plt.savefig("results/metrics.png", dpi=130)
res["_meta"] = {"data": ds.source, "ranker": ranker.backend, "als": ret.backend,
                "train_rows": int(len(train)), "seconds": round(time.time() - t0)}
json.dump(res, open("results/metrics.json", "w"), indent=2, ensure_ascii=False)
log("saved results/metrics.json")
