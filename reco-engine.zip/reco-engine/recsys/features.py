import warnings
import numpy as np
import pandas as pd
from .snapshot import Snapshot

FEATURES = [
    "als_score", "als_rank", "src_als", "src_fresh", "src_trend",
    "last_sim_max", "last_sim_mean",
    "item_log_pop", "item_log_pop7", "item_trend_ratio", "item_cart_rate", "item_buy_rate", "item_age_d",
    "item_logprice",
    "u_n_events", "u_n_items", "u_days_since",
    "u_cat_share", "u_cat_share7", "u_price_diff",
]


def build_features(cands: pd.DataFrame, snap: Snapshot, ret) -> pd.DataFrame:
    s = snap
    d = cands.copy()
    u, i = d["user"].values, d["item"].values
    d["als_score"] = np.einsum("ij,ij->i", ret.UF[u], ret.IF[i])
    d.loc[s.u_items[u] == 0, "als_score"] = np.nan            # у холодного пользователя вектора нет
    d["als_rank"] = d.groupby("user")["als_score"].rank(ascending=False)
    for c in ("src_als", "src_fresh", "src_trend"):
        d[c] = d[c].astype("int8")
    # item-item похожесть на последние 5 товаров пользователя (косинус по ALS-векторам)
    last = s.last5[u]                                           # P x 5
    sims = np.einsum("pf,pkf->pk", ret.IFn[i], ret.IFn[np.where(last >= 0, last, 0)])
    sims = np.where(last >= 0, sims, np.nan)
    with np.errstate(all="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d["last_sim_max"] = np.nanmax(np.where(np.isnan(sims), -np.inf, sims), axis=1)
        d["last_sim_mean"] = np.nanmean(sims, axis=1)
    d.loc[~np.isfinite(d["last_sim_max"]), "last_sim_max"] = np.nan
    # item
    d["item_log_pop"] = np.log1p(s.item_n_all[i])
    d["item_log_pop7"] = np.log1p(s.item_n7[i])
    d["item_trend_ratio"] = (s.item_n7[i] + 1) / (s.item_n_all[i] + 1)
    d["item_cart_rate"] = (s.item_carts[i] + 0.1) / (s.item_views[i] + 10)    # сглаживание для холодных
    d["item_buy_rate"] = (s.item_buys[i] + 0.03) / (s.item_views[i] + 10)
    d["item_age_d"] = s.item_age_d[i]
    d["item_logprice"] = s.logprice[i]
    # user
    d["u_n_events"] = s.u_n[u]; d["u_n_items"] = s.u_items[u]; d["u_days_since"] = s.u_days_since[u]
    d["u_cat_share"] = s.cat_share(s.u_cat, s.u_cat_n, u, i)
    d["u_cat_share7"] = s.cat_share(s.u_cat7, s.u_cat7_n, u, i)
    d["u_price_diff"] = s.logprice[i] - s.u_lp[u]
    return d


def add_labels(d: pd.DataFrame, ds, T0: int, T1: int, snap: Snapshot):
    """Позитив = пользователь провзаимодействовал с товаром в окне [T0,T1), которого НЕ было в истории,
    и товар существовал в каталоге на момент T0 (иначе его не мог рекомендовать никто)."""
    e = ds.events
    w = e[(e["ts"] >= T0) & (e["ts"] < T1)]
    w = w[snap.known[w["item"].values]]
    key = w["user"].values * ds.n_items + w["item"].values
    key = np.unique(key)
    seen = snap.R[key // ds.n_items, key % ds.n_items].A1 > 0
    key = key[~seen]
    d["label"] = np.isin(d["user"].values * ds.n_items + d["item"].values, key).astype("int8")
    pos_count = pd.Series(key // ds.n_items).value_counts().sort_index()
    return d, pos_count
