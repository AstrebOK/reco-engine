"""Snapshot = всё, что система знает о мире на момент T (только события ДО T -> нет утечки)."""
import numpy as np
import pandas as pd
import scipy.sparse as sp
from .data import Dataset, DAY

W = np.array([1.0, 3.0, 5.0])  # вес события: view / addtocart / transaction


class Snapshot:
    def __init__(self, ds: Dataset, T: int):
        self.ds, self.T = ds, T
        e = ds.events
        h = e[e["ts"] < T]
        self.hist = h
        nu, ni, nc = ds.n_users, ds.n_items, ds.n_cats
        u, i, t = h["user"].values, h["item"].values, h["ts"].values
        w = W[h["etype"].values]
        # user-item матрица взаимодействий (сумма весов)
        self.R = sp.csr_matrix((w, (u, i)), shape=(nu, ni))
        # item-статистика
        self.item_views = np.bincount(i[h["etype"].values == 0], minlength=ni)
        self.item_carts = np.bincount(i[h["etype"].values == 1], minlength=ni)
        self.item_buys = np.bincount(i[h["etype"].values == 2], minlength=ni)
        rec = t >= T - 7 * DAY
        self.item_n7 = np.bincount(i[rec], minlength=ni)
        self.item_n_all = np.bincount(i, minlength=ni)
        fs = np.full(ni, np.inf)
        np.minimum.at(fs, i, t)
        self.first_seen = fs                       # inf = товар в истории не встречался
        self.known = np.isfinite(fs)
        self.item_age_d = np.where(self.known, (T - fs) / DAY, np.nan)
        # user-статистика
        self.u_n = np.bincount(u, minlength=nu)
        self.u_items = np.diff(self.R.indptr)
        last = np.full(nu, -np.inf)
        np.maximum.at(last, u, t)
        self.u_days_since = np.where(self.u_n > 0, (T - last) / DAY, np.nan)
        cat = ds.items["cat"].values
        self.logprice = np.log1p(ds.items["price"].values)
        self.u_cat = sp.csr_matrix((np.ones(len(u)), (u, cat[i])), shape=(nu, nc))
        self.u_cat_n = np.asarray(self.u_cat.sum(1)).ravel()
        self.u_cat7 = sp.csr_matrix((np.ones(rec.sum()), (u[rec], cat[i[rec]])), shape=(nu, nc))
        self.u_cat7_n = np.asarray(self.u_cat7.sum(1)).ravel()
        self.u_lp = np.where(self.u_n > 0, np.bincount(u, weights=self.logprice[i], minlength=nu) /
                             np.maximum(self.u_n, 1), np.nan)
        # последние 5 товаров пользователя (для item-item похожести)
        self.last5 = np.full((nu, 5), -1, dtype=np.int64)
        hs = h.sort_values("ts")
        g = hs.groupby("user")["item"].apply(lambda s: s.values[-5:])
        for uu, arr in g.items():
            self.last5[uu, -len(arr):] = arr
        self.cat = cat

    def cat_share(self, M, Mn, users, items):
        v = np.asarray(M[users, self.cat[items]]).ravel()
        n = Mn[users]
        return np.where(n > 0, v / np.maximum(n, 1), np.nan)
