"""Загрузка данных: настоящий RetailRocket или синтетика в том же формате.

Единая внутренняя схема:
  events: user(int), item(int), etype(0=view,1=addtocart,2=transaction), ts(ms)
  items : index = item code; cat(int), price(float)
"""
from __future__ import annotations
import os
from dataclasses import dataclass
import numpy as np
import pandas as pd

DAY = 86_400_000
ETYPE = {"view": 0, "addtocart": 1, "transaction": 2}


@dataclass
class Dataset:
    events: pd.DataFrame
    items: pd.DataFrame
    n_users: int
    n_items: int
    n_cats: int
    source: str


def load_retailrocket(path: str) -> Dataset:
    """Ожидает файлы Kaggle 'retailrocket/ecommerce-dataset' в `path`:
    events.csv, item_properties_part1.csv, item_properties_part2.csv"""
    ev = pd.read_csv(os.path.join(path, "events.csv"))
    ev = ev[ev["event"].isin(ETYPE)].copy()
    ev["etype"] = ev["event"].map(ETYPE).astype("int8")
    ev = ev.rename(columns={"visitorid": "user", "itemid": "item", "timestamp": "ts"})
    props = pd.concat(
        [pd.read_csv(os.path.join(path, f"item_properties_part{i}.csv")) for i in (1, 2)]
    )
    props = props[props["property"].isin(["categoryid", "790"])].sort_values("timestamp")
    last = props.groupby(["itemid", "property"])["value"].last().unstack()
    items = pd.DataFrame(index=pd.Index(ev["item"].unique(), name="item_raw"))
    cat_raw = last["categoryid"].reindex(items.index) if "categoryid" in last else pd.Series(-1, index=items.index)
    price = (pd.to_numeric(last["790"].astype(str).str.lstrip("n"), errors="coerce").reindex(items.index)
             if "790" in last else pd.Series(np.nan, index=items.index))
    ucode, uniq_u = pd.factorize(ev["user"])
    icode = items.index.get_indexer(ev["item"])
    cat_code, _ = pd.factorize(cat_raw.fillna(-1))
    items = pd.DataFrame({"cat": cat_code, "price": price.fillna(price.median()).values})
    events = pd.DataFrame({"user": ucode, "item": icode, "etype": ev["etype"].values, "ts": ev["ts"].values})
    return Dataset(events.sort_values("ts").reset_index(drop=True), items,
                   len(uniq_u), len(items), int(items["cat"].max()) + 1, "RetailRocket")


def generate_synthetic(n_users=6000, n_items=3000, n_days=120, n_clusters=14,
                       dim=8, beta=2.2, seed=42) -> Dataset:
    """Синтетика, имитирующая формат RetailRocket (view -> addtocart -> transaction).

    Заложенная структура:
      * у пользователей и товаров есть скрытые вкусы/векторы, категория = кластер товара;
      * популярность товаров — степенной закон; товары «запускаются» в разные дни (холодные товары);
      * пользователи приходят в разные дни (холодные пользователи);
      * активность пользователей — тяжёлый хвост;
      * выбор товара ~ softmax(beta * u.v + log popularity), только среди уже запущенных.
    """
    rng = np.random.default_rng(seed)
    centers = rng.normal(size=(n_clusters, dim))
    cat = rng.integers(0, n_clusters, n_items)
    V = centers[cat] + 0.6 * rng.normal(size=(n_items, dim))
    pop = rng.lognormal(0, 1.0, n_items)
    launch = np.where(rng.random(n_items) < 0.45, 0, rng.uniform(0, n_days - 3, n_items))
    price = np.exp(rng.normal(3 + 0.15 * (cat % 5), 0.5))

    taste = np.zeros((n_users, n_clusters))
    c1 = rng.integers(0, n_clusters, n_users)
    c2 = rng.integers(0, n_clusters, n_users)
    taste[np.arange(n_users), c1] += rng.uniform(0.4, 1.0, n_users)
    taste[np.arange(n_users), c2] += rng.uniform(0, 0.8, n_users) * (rng.random(n_users) < 0.6)
    U = taste @ centers / taste.sum(1, keepdims=True) + 0.3 * rng.normal(size=(n_users, dim))
    join = np.where(rng.random(n_users) < 0.5, 0, rng.uniform(0, n_days - 2, n_users))
    rate = rng.lognormal(-1.4, 0.9, n_users)  # событий в день

    S = (beta * (U @ V.T) / np.sqrt(dim) + np.log(pop)).astype(np.float32)
    rows = []
    for d in range(n_days):
        act = np.where(join <= d)[0]
        users = np.repeat(act, rng.poisson(rate[act]))
        if len(users) == 0:
            continue
        logits = S[users].copy()
        logits[:, launch > d] = -np.inf
        g = -np.log(-np.log(rng.random(logits.shape, dtype=np.float32) + 1e-12) + 1e-12)
        it = np.argmax(logits + g, axis=1)
        ts = 1_430_000_000_000 + d * DAY + rng.integers(0, DAY, len(users))
        pref = 1 / (1 + np.exp(-(S[users, it] - np.log(pop[it]) - 0.8)))
        cart = rng.random(len(users)) < 0.015 + 0.10 * pref
        buy = cart & (rng.random(len(users)) < 0.35)
        base = pd.DataFrame({"user": users, "item": it, "etype": 0, "ts": ts})
        rows += [base, base[cart].assign(etype=1, ts=lambda x: x.ts + 60_000),
                 base[buy].assign(etype=2, ts=lambda x: x.ts + 600_000)]
    events = pd.concat(rows).sort_values("ts").reset_index(drop=True)
    events = events.astype({"user": "int64", "item": "int64", "etype": "int8"})
    items = pd.DataFrame({"cat": cat, "price": price})
    return Dataset(events, items, n_users, n_items, n_clusters, "synthetic (RetailRocket-like)")


def load(path: str = "data/retailrocket", **kw) -> Dataset:
    if os.path.exists(os.path.join(path, "events.csv")):
        return load_retailrocket(path)
    return generate_synthetic(**kw)
