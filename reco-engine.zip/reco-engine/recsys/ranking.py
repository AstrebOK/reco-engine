"""Стадия 2 — Ranking: переупорядочить 50 кандидатов по вероятности позитивного исхода."""
import numpy as np
import pandas as pd

try:
    from catboost import CatBoostRanker, Pool
    BACKEND = "catboost"
except Exception:
    try:
        import lightgbm as lgb
        BACKEND = "lightgbm"
    except Exception:
        BACKEND = "sklearn"


class Ranker:
    def __init__(self, features, seed=0):
        self.features, self.seed, self.backend = features, seed, BACKEND

    def fit(self, d: pd.DataFrame):
        # группы без единого позитива не несут сигнала для ранжирующих лоссов -> выкидываем
        has_pos = d.groupby("user")["label"].transform("max") > 0
        d = d[has_pos].sort_values("user")
        X, y = d[self.features], d["label"]
        if self.backend == "catboost":
            self.m = CatBoostRanker(loss_function="YetiRank", iterations=400, depth=6, learning_rate=0.08,
                                    random_seed=self.seed, verbose=0)
            self.m.fit(Pool(X, y, group_id=d["user"].values))
        elif self.backend == "lightgbm":
            self.m = lgb.LGBMRanker(objective="lambdarank", n_estimators=400, learning_rate=0.05,
                                    num_leaves=31, random_state=self.seed, verbose=-1)
            self.m.fit(X, y, group=d.groupby("user", sort=True).size().values)
        else:  # fallback: pointwise-классификатор клика (на ранжирование по группам не влияет калибровка)
            from sklearn.ensemble import HistGradientBoostingClassifier
            self.m = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.06, max_leaf_nodes=24,
                                                    l2_regularization=1.0, random_state=self.seed)
            self.m.fit(X, y)
        return self

    def predict(self, d: pd.DataFrame) -> np.ndarray:
        X = d[self.features]
        if self.backend == "sklearn":
            return self.m.predict_proba(X)[:, 1]
        return self.m.predict(X)
