"""Стадия 1 — Retrieval: быстро сузить каталог (тысячи..миллионы) до ~50 кандидатов на пользователя.

Источники кандидатов (смешиваются с квотами):
  1. ALS (матричная факторизация, implicit feedback) — персональный «основной» источник.
  2. Fresh  — новые товары (появились в логах <= 7 дней назад), взвешены по любимым категориям
              пользователя. Решает cold start ТОВАРОВ: у них ещё нет надёжного вектора в ALS.
  3. Trend  — глобально популярное за 7 дней. Решает cold start ПОЛЬЗОВАТЕЛЕЙ и добивает список.
"""
import numpy as np
import pandas as pd
from .snapshot import Snapshot

try:  # опционально: быстрая реализация
    import implicit  # noqa
    HAS_IMPLICIT = True
except Exception:
    HAS_IMPLICIT = False


def als_fit(R, factors=32, reg=0.1, alpha=15.0, iters=12, seed=0):
    """Implicit ALS (Hu, Koren, Volinsky 2008): confidence c = 1 + alpha*log1p(r), preference p = 1[r>0]."""
    if HAS_IMPLICIT:
        try:
            from implicit.als import AlternatingLeastSquares
            C = R.copy(); C.data = 1 + alpha * np.log1p(C.data)
            m = AlternatingLeastSquares(factors=factors, regularization=reg, iterations=iters,
                                        random_state=seed, use_gpu=False)
            m.fit(C.tocsr(), show_progress=False)
            return np.asarray(m.user_factors), np.asarray(m.item_factors), "implicit"
        except Exception:
            pass
    rng = np.random.default_rng(seed)
    nu, ni = R.shape
    C = R.copy().tocsr(); C.data = alpha * np.log1p(C.data)   # (c - 1)
    CT = C.T.tocsr()
    X = np.zeros((nu, factors)); Y = 0.1 * rng.normal(size=(ni, factors))

    def solve(Cm, Fix):
        out = np.zeros((Cm.shape[0], factors)); FtF = Fix.T @ Fix + reg * np.eye(factors)
        for r in range(Cm.shape[0]):
            s, e = Cm.indptr[r], Cm.indptr[r + 1]
            if s == e:
                continue
            idx, cm1 = Cm.indices[s:e], Cm.data[s:e]
            F = Fix[idx]
            out[r] = np.linalg.solve(FtF + (F.T * cm1) @ F, ((1 + cm1)[:, None] * F).sum(0))
        return out
    for _ in range(iters):
        X = solve(C, Y); Y = solve(CT, X)
    return X, Y, "numpy-als"


class Retriever:
    def __init__(self, snap: Snapshot, n_total=50, quota_als=40, quota_fresh=10,
                 cold_quota_fresh=20, fresh_days=7, min_item_events=3, **als_kw):
        self.s, self.n, self.qa, self.qf, self.cqf = snap, n_total, quota_als, quota_fresh, cold_quota_fresh
        self.UF, self.IF, self.backend = als_fit(snap.R, **als_kw)
        s = snap
        # ALS-eligible: достаточно событий, чтобы вектор что-то значил
        self.als_ok = s.item_n_all >= min_item_events
        self.fresh_ids = np.where(s.known & (s.item_age_d <= fresh_days))[0]
        nrm = np.linalg.norm(self.IF, axis=1, keepdims=True)
        self.IFn = self.IF / np.maximum(nrm, 1e-9)
        order = np.argsort(-s.item_n7)
        self.trend = order[s.item_n7[order] > 0][:2000]

    def candidates(self, users: np.ndarray, block=256) -> pd.DataFrame:
        s = self.s
        recs = []
        for b in range(0, len(users), block):
            ub = users[b:b + block]
            warm = s.u_items[ub] > 0
            sc = self.UF[ub] @ self.IF.T
            sc[:, ~self.als_ok] = -np.inf
            sc[s.R[ub].nonzero()] = -np.inf  # уже видели — не рекомендуем повторно
            top = np.argpartition(-sc, self.qa, axis=1)[:, :self.qa]
            # fresh: популярность 7д + аффинность к категориям пользователя
            fr = self.fresh_ids
            if len(fr):
                aff = np.asarray(s.u_cat[ub][:, s.cat[fr]].todense()) / np.maximum(s.u_cat_n[ub], 1)[:, None]
                fs = np.log1p(s.item_n7[fr])[None, :] + 3.0 * aff
                fs[s.R[ub][:, fr].toarray() > 0] = -np.inf
            for j, u in enumerate(ub):
                cand, src_a, src_f, src_t = [], set(), set(), set()
                if warm[j]:
                    t = top[j][np.argsort(-sc[j, top[j]])]
                    t = t[np.isfinite(sc[j, t])]
                    cand += list(t); src_a = set(t)
                nf = self.qf if warm[j] else self.cqf
                if len(fr) and nf:
                    k = min(nf, len(fr))
                    f = fr[np.argsort(-fs[j])[:k]]
                    f = f[np.isfinite(fs[j][np.searchsorted(fr, f)])]
                    cand += list(f); src_f = set(f)
                seen = set(s.R.indices[s.R.indptr[u]:s.R.indptr[u + 1]])
                for it in self.trend:        # добиваем трендом до n_total
                    if len(set(cand)) >= self.n:
                        break
                    if it not in seen:
                        cand.append(it); src_t.add(it)
                cand = list(dict.fromkeys(cand))[:self.n]
                for it in cand:
                    recs.append((u, it, it in src_a, it in src_f, it in src_t))
        df = pd.DataFrame(recs, columns=["user", "item", "src_als", "src_fresh", "src_trend"])
        df[["user", "item"]] = df[["user", "item"]].astype("int64")
        return df
