import numpy as np
import pandas as pd


def rank_metrics(df: pd.DataFrame, score_col: str, pos_count: pd.Series, ks=(10,)) -> dict:
    """df: user,item,label,<score_col> — кандидаты. pos_count: число релевантных на пользователя
    (ВСЕ позитивы окна, включая не попавшие в кандидаты -> честный знаменатель Recall).
    Считаются только пользователи из pos_count.index."""
    d = df.sort_values(["user", score_col], ascending=[True, False]).copy()
    d["rank"] = d.groupby("user").cumcount()
    users = pos_count.index
    out = {}
    for k in ks:
        top = d[d["rank"] < k]
        hits = top.groupby("user")["label"].sum().reindex(users, fill_value=0)
        disc = 1.0 / np.log2(top["rank"].values + 2)
        dcg = pd.Series(top["label"].values * disc, index=top["user"].values).groupby(level=0).sum()
        dcg = dcg.reindex(users, fill_value=0.0)
        ideal = pd.Series([(1.0 / np.log2(np.arange(2, min(n, k) + 2))).sum() for n in pos_count.values],
                          index=users)
        out[f"Recall@{k}"] = float((hits / pos_count).mean())
        out[f"HitRate@{k}"] = float((hits > 0).mean())
        out[f"NDCG@{k}"] = float((dcg / ideal).mean())
    out["n_users"] = int(len(users))
    out["_top_items"] = d[d["rank"] < ks[0]]["item"].values  # покрытие считаем по первому K (=10)
    return out
