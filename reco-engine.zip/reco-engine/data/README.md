Положите сюда папку `retailrocket/` с файлами Kaggle (retailrocket/ecommerce-dataset):
events.csv, item_properties_part1.csv, item_properties_part2.csv
